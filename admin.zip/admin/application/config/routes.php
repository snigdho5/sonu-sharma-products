<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$route['default_controller'] = 'Auth/index';
$route['404_override'] = 'Auth/get404';
$route['translate_uri_dashes'] = FALSE;


//login
$route['login'] = 'Auth/onSetLogin';
$route['chk_login'] = 'Auth/onCheckLogin';
$route['logout'] = 'Auth/onSetLogout';
$route['dashboard'] = 'Auth/onGetDashboard';

//user management
$route['users'] = 'Users/index';
$route['duplicate_check_un'] = 'Users/onCheckDuplicateUser';
$route['adduser'] = 'Users/onCreateUserView';
$route['createuser'] = 'Users/onCreateUser';
$route['profile'] = 'Users/onGetUserProfile/';
$route['profile/(:num)'] = 'Users/onGetUserProfile/$1';
$route['changeprofile'] = 'Users/onChangeUserProfile';
$route['deluser'] = 'Users/onDeleteUser';


//contact us
$route['contactus'] = 'Main/onGetContactUs';
$route['deletecont'] = 'Main/onDeleteContUs';
$route['editdealer/(:num)'] = 'Main/onGetContactUsView/$1';
$route['savecont'] = 'Main/onSetContUsEdit';


//Website Visits
$route['visits'] = 'Stats/index';
$route['deleteconnections'] = 'Stats/onDeleteConnections';
