<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 */
class Main_model extends MY_Model {


	function __construct(){
		//
	}

	//contact us
	public function addCont($data){
		$this->table='contact_us';
		return $this->store($data);
	}

	public function getContData($param=null,$many=FALSE){
		$this->table='contact_us';
		if($param!=null && $many==FALSE){
			return $this->get_one($param);
		}
		elseif($param!=null && $many==TRUE){
			return $this->get_many($param,$order_by='id',$order='DESC',FALSE);
		}
		elseif($param==null && $many==TRUE){
			return $this->get_many($param,$order_by='id',$order='DESC',FALSE);
		}
		else{
			return $this->get_many();
		}
	}

	public function updateCont($data,$param){
		$this->table='contact_us';
		return $this->modify($data,$param);
	}

	public function delCont($param){
		$this->table='contact_us';
		return $this->remove($param);
	}

	
	


}
