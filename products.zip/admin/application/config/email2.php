<?php
$config = array(
	'protocol' => 'smtp',
	'smtp_host' => 'sg2plcpnl0064.prod.sin2.secureserver.net',
	'smtp_port' => 465,
	'smtp_user' => 'noreply@smarttraininghub.com',
	'smtp_pass' => 'sS-1H=cs!m@c',
	'smtp_crypto' => 'ssl',
	'mailtype' => 'html',
	'smtp_timeout' => '4',
	'charset' => 'iso-8859-1',
	'wordwrap' => TRUE
);
?>
