<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Main extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		$this->load->helper('form');
		$this->load->library('form_validation');
	}

	public function index()
	{
		//
	}

	//cont us
	public function onGetContactUs()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1)
		{

			$contdata = $this->mm->getContData($p=null,$many=TRUE);
			if($contdata){
				foreach ($contdata as $key => $value) {
					$this->data['cont_data'][] = array(
						'cont_id'  => $value->cont_id,
						'name'  => $value->name,
						'phone'  => $value->phone,
						'message'  => $value->message,
						'email'  => $value->email,
						'added_source'  => $value->added_source,
						'iplocation'  => $value->created_ip,
						'dtime'  => $value->dtime
					);
				}
			}
			else{
				$this->data['cont_data'] = '';
			}
			$this->load->view('main/vw_contacts', $this->data, false);
		

		}
		else{
			redirect(base_url());
		}
			
		
	}


	public function onDeleteContUs()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
		   if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

			$cont_id = xss_clean($this->input->post('contid'));
			$contdata = $this->mm->getContData(array('cont_id'  => $cont_id),$many=FALSE);

			if($contdata){
				//del
				$delcont = $this->mm->delCont(array('cont_id' => $cont_id));

				if($delcont){
					$return['deleted'] = 'success';
				}
				else{
					$return['deleted'] = 'failure';
				}
					
			}
			else{
				$return['deleted'] = 'not_exists';
			}

			header('Content-Type: application/json');
			echo json_encode($return);	

			}else{
				redirect(base_url());
			}
		}
 	}
	
	//affiliation
	public function onGetAffiliation()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1)
		{

			$affData = $this->mm->getAffiData($p=null,$many=TRUE);
			if($affData){
				foreach ($affData as $key => $value) {
					$this->data['aff_data'][] = array(
						'affiliation_id'  => $value->affiliation_id,
						'institution_name'  => $value->institution_name,
						'address'  => $value->address,
						'phone_no'  => $value->phone_no,
						'organiser'  => $value->organiser,
						'no_of_students'  => $value->no_of_students,
						'dtime'  => $value->created_dtime
						// 'father_name'  => $value->father_name,
						// 'age'  => $value->age,
						// 'gender'  => $value->gender,
						// 'foundation_year'  => $value->foundation_year,
						// 'whether_registered'  => $value->whether_registered,
						// 'subject'  => $value->subject,
						// 'educational_qualifications'  => $value->educational_qualifications,
						// 'art_qualification'  => $value->art_qualification,
						// 'address_proof_id'  => $value->address_proof_id,
						// 'eq_certificate_id'  => $value->eq_certificate_id,
						// 'art_certificate_id'  => $value->art_certificate_id,
						// 'photo_id'  => $value->photo_id,
						// 'signature_id'  => $value->signature_id,
						// 'ip'  => $value->iplocation
					);
				}
			}
			else{
				$this->data['aff_data'] = '';
			}
			$this->load->view('main/vw_affiliations', $this->data, false);
		

		}
		else{
			redirect(base_url());
		}
			
		
	}

	

	public function onGetAffbyId()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
		   if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

			$affid = xss_clean($this->input->post('affid'));
			$affData = $this->mm->getAffiData(array('affiliation_id'  => $affid),$many=FALSE);

			if($affData){

				if(isset($affData->iplocation) && $affData->iplocation!='::1' && $affData->iplocation!=''){
					$ip_data = '';
					$iplocation = getiplocation($affData->iplocation);
					$ip_data .= '<br>IP: '.$affData->iplocation; 
					$ip_data .= '<br>Country: '.$iplocation->country; 
					$ip_data .= '<br>Region: '.$iplocation->regionName; 
					$ip_data .= '<br>City: '.$iplocation->city; 
				}
				else{
					$ip_data = 'N/A';
				}
					$return['aff_data'] = array(
						'affiliation_id'  => $affData->affiliation_id,
						'institution_name'  => $affData->institution_name,
						'address'  => $affData->address,
						'phone_no'  => $affData->phone_no,
						'organiser'  => $affData->organiser,
						'father_name'  => $affData->father_name,
						'age'  => $affData->age,
						'gender'  => $affData->gender,
						'foundation_year'  => $affData->foundation_year,
						'whether_registered'  => $affData->whether_registered,
						'subject'  => $affData->subject,
						'no_of_students'  => $affData->no_of_students,
						'educational_qualifications'  => $affData->educational_qualifications,
						'art_qualification'  => $affData->art_qualification,
						'address_proof_id'  => $affData->address_proof_id,
						'eq_certificate_id'  => $affData->eq_certificate_id,
						'art_certificate_id'  => $affData->art_certificate_id,
						'photo_id'  => $affData->photo_id,
						'signature_id'  => $affData->signature_id,
						'ip'  => $ip_data,
						'dtime'  => $affData->created_dtime
					);

					$files = $this->mm->getUploadsData(array('unique_id'  => $affData->unique_id),$many=TRUE);
					//print_obj($files);die;
					if($files){
						foreach ($files as $key => $value) {

							if($value->module_name == 'signature_aff'){
								$return['signature_aff_fp'] = $value->file_path;
							}
							 else if($value->module_name == 'photo_aff'){
								$return['photo_aff_fp'] = $value->file_path;
							}
							 else if($value->module_name == 'art_certificate'){
								$return['art_certificate_fp'] = $value->file_path;
							}
							 else if($value->module_name == 'eq_certificate'){
								$return['eq_certificate_fp'] = $value->file_path;
							}
							 else if($value->module_name == 'address_proof'){
								$return['address_proof_fp'] = $value->file_path;
							}
							else{
								$return['signature_aff_fp'] = ($return['signature_aff_fp'] != 'undefined' && $return['signature_aff_fp'] != '')?'':'undefined';
								$return['photo_aff_fp'] = ($return['photo_aff_fp'] != 'undefined' && $return['photo_aff_fp'] != '')?'':'0';
								$return['art_certificate_fp'] = ($return['art_certificate_fp'] != 'undefined' && $return['art_certificate_fp'] != '')?'':'undefined';
								$return['eq_certificate_fp'] = ($return['eq_certificate_fp'] != 'undefined' && $return['eq_certificate_fp'] != '')?'':'undefined';
								$return['address_proof_fp'] = ($return['address_proof_fp'] != 'undefined' && $return['address_proof_fp'] != '')?'':'undefined';
							}
							
						}
					}else{
							$return['signature_aff_fp'] = 'undefined';
							$return['photo_aff_fp'] = 'undefined';
							$return['art_certificate_fp'] = 'undefined';
							$return['eq_certificate_fp'] = 'undefined';
							$return['address_proof_fp'] = 'undefined';
					}
			}
			else{
				$return['aff_data'] = '';
			}
			//print_obj($return);die;

			header('Content-Type: application/json');
			echo json_encode($return);	

			}else{
				redirect(base_url());
			}
		}
	 }


	public function onDeleteAff()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
		   if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

			$affid = xss_clean($this->input->post('affid'));
			$affData = $this->mm->getAffiData(array('affiliation_id'  => $affid),$many=FALSE);

			if($affData){
				//del
				$delaff = $this->mm->delAff(array('affiliation_id' => $affid));

				if($delaff){
					$return['deleted'] = 'success';
				}
				else{
					$return['deleted'] = 'failure';
				}
					
			}
			else{
				$return['deleted'] = 'not_exists';
			}

			header('Content-Type: application/json');
			echo json_encode($return);	

			}else{
				redirect(base_url());
			}
		}
	 }
	 
	 //payments
	public function onGetPayments()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1)
		{

			$paydata = $this->mm->getPaymentsData($p=null,$many=TRUE);
			if($paydata){
				foreach ($paydata as $key => $value) {
					$this->data['payments_data'][] = array(
						'pay_id'  => $value->pay_id,
						'course_name'  => $value->course_name,
						'course_amt'  => $value->course_amt,
						'payee_name'  => $value->payee_name,
						'payee_phone'  => $value->payee_phone,
						'payee_email'  => $value->payee_email,
						'payee_address'  => $value->payee_address,
						'razorpay_payment_id'  => $value->razorpay_payment_id,
						'razorpay_order_id'  => $value->razorpay_order_id,
						'razorpay_signature'  => $value->razorpay_signature,
						'date_created'  => $value->date_created
					);
				}
			}
			else{
				$this->data['payments_data'] = '';
			}
			$this->load->view('main/vw_payments', $this->data, false);
		

		}
		else{
			redirect(base_url());
		}
			
		
	}



 	
	

}
