<footer class="footer text-center">
	Copyright &copy; <?php echo (date('Y')>2020)?('2020 - '.date('Y')):'2020'; ?> <a href="javascript:void(0)"> <?php echo comp_name; ?> </a> | All Rights Reserved.
</footer>
