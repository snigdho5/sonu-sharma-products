<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
	<?php $this->load->view('top_css'); ?>
	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'common/assets/extra-libs/multicheck/multicheck.css'; ?>">
	<link href="<?php echo base_url() . 'common/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css'; ?>" rel="stylesheet">
	<title><?php echo comp_name; ?> | Affiliations</title>
</head>

<body>
	<!-- ============================================================== -->
	<!-- Preloader - style you can find in spinners.css -->
	<!-- ============================================================== -->
	<div class="preloader">
		<div class="lds-ripple">
			<div class="lds-pos"></div>
			<div class="lds-pos"></div>
		</div>
	</div>
	<!-- ============================================================== -->
	<!-- Main wrapper - style you can find in pages.scss -->
	<!-- ============================================================== -->
	<div id="main-wrapper">
		<!-- ============================================================== -->
		<!-- Topbar header - style you can find in pages.scss -->
		<?php $this->load->view('header_main'); ?>
		<!-- End Topbar header -->
		<!-- Left Sidebar - style you can find in sidebar.scss  -->
		<?php $this->load->view('sidebar_main'); ?>
		<!-- End Left Sidebar - style you can find in sidebar.scss  -->
		<!-- ============================================================== -->
		<div class="page-wrapper">
			<!-- ============================================================== -->
			<div class="page-breadcrumb">
				<div class="row">
					<div class="col-12 d-flex no-block align-items-center">
						<h4 class="page-title">Affiliations</h4>
						<div class="ml-auto text-right">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="#">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Affiliations</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<!-- ============================================================== -->
			<div class="container-fluid">
				<!-- ============================================================== -->
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<h5 class="card-title">Affiliations</h5>
								<div class="table-responsive">
									<table id="zero_config" class="table table-striped table-bordered">
										<thead>
											<tr class="textcen">
												<th>Sl</th>
												<th>Created On</th>
												<th>Institution</th>
												<th>Phone</th>
												<th>Principal/Org</th>
												<th>Students</th>
												<th>Action</th>

											</tr>
										</thead>
										<tbody class="textcen">
											<?php
											if (!empty($aff_data)) {
												//print_obj($aff_data);
												$sl = 1;
												foreach ($aff_data as $key => $val) {
											?>
													<tr>
														<td><?php echo $sl; ?></td>
														<td><?php echo $val['dtime']; ?></td>
														<td><?php echo $val['institution_name']; ?></td>
														<td><?php echo $val['phone_no']; ?></td>
														<td><?php echo $val['organiser']; ?></td>
														<td><?php echo $val['no_of_students']; ?></td>
														<td>
															<?php if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in') == 1 && $this->session->userdata('usergroup') == 1) {  ?>
																<button type="button" class="btn btn-cyan btn-sm view_aff" data-affid="<?php echo $val['affiliation_id']; ?>"><i class="icofont-eye-alt"></i></button>
																<button type="button" class="btn btn-danger btn-sm del_aff" data-affid="<?php echo $val['affiliation_id']; ?>" data-name="<?php echo $val['institution_name']; ?>"><i class="fas fa-trash-alt"></i></button>
															<?php } ?>
														</td>
													</tr>
												<?php
													$sl++;
												}
											} else {
												?>
												<tr>
													<td colspan="6">No data found</td>
												</tr>
											<?php
											}
											?>
										</tbody>
									</table>
								</div>

							</div>
						</div>
					</div>
				</div>
				<!-- ============================================================== -->
			</div>
			<!-- ============================================================== -->
			<!-- End Container fluid  -->
			<!-- ============================================================== -->
			<!-- ============================================================== -->
			<!-- footer -->
			<!-- ============================================================== -->
			<?php $this->load->view('footer'); ?>
			<!-- ============================================================== -->
			<!-- End footer -->
			<!-- ============================================================== -->
		</div>
		<!-- ============================================================== -->
		<!-- End Page wrapper  -->
		<!-- ============================================================== -->
	</div>

	<!-- Modal -->
	<div class="modal fade" id="Modal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Affiliation Details</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<p><span id="institution_name"></span><br />
					<span id="address"></span><br />
					<span id="phone_no"></span> <span id="organiser"></span><br />
					<span id="father_name"></span> <span id="age"></span><br />
					<span id="gender"></span> <span id="foundation_year"></span></p>

					<p>
						<span id="signature_aff_fp"></span> <span id="photo_aff_fp"></span><br />
						<span id="eq_certificate_fp"></span> <span id="art_certificate_fp"></span><br />
						<span id="address_proof_fp"></span>
					</p>

					<p><span id="ip"></span>
					<br /><span id="dtime"></span></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<!-- ============================================================== -->
	<!-- End Wrapper -->
	<?php $this->load->view('bottom_js'); ?>
	<!-- this page js -->
	<script src="<?php echo base_url() . 'common/assets/extra-libs/multicheck/datatable-checkbox-init.js'; ?>"></script>
	<script src="<?php echo base_url() . 'common/assets/extra-libs/multicheck/jquery.multicheck.js'; ?>"></script>
	<script src="<?php echo base_url() . 'common/assets/extra-libs/DataTables/datatables.min.js'; ?>"></script>
	<script>
		/****************************************
		 *       Basic Table                   *
		 ****************************************/
		$('#zero_config').DataTable();

		$(document).ready(function() {
			$(".del_aff").click(function() {

				var affid = $(this).attr('data-affid');
				var name = $(this).attr('data-name');

				conf = confirm('Are you sure to delete ' + name + '?');
				if (conf) {
					$.ajax({

						type: 'POST',

						url: '<?php echo base_url(); ?>deleteaff',

						data: {
							affid: affid
						},

						success: function(d) {

							if (d.deleted == 'success') {

								alert('Deleted!');
								window.location.reload();

							} else if (d.deleted == 'not_exists') {

								alert('Does not exists!');

							} else {
								alert('Something went wrong!');
							}

						}

					});
				}
			});

			$(".view_aff").click(function() {

				var affid = $(this).attr('data-affid');

				$.ajax({

					type: 'POST',
					url: '<?php echo base_url(); ?>viewaff',
					data: {affid: affid},
					success: function(data) {
						
						//console.log(data.aff_data);
						if (data.aff_data != '') {
							$("#institution_name").html('<b>Institution Name: </b>'+data.aff_data['institution_name']);
							$("#address").html('<b>Address: </b>'+data.aff_data['address']);
							$("#phone_no").html('<b>Phone: </b>'+data.aff_data['phone_no']);
							$("#organiser").html('<b>Organiser: </b>'+data.aff_data['organiser']);
							$("#father_name").html('<b>Father Name: </b>'+data.aff_data['father_name']);
							$("#age").html('<b>Age: </b>'+data.aff_data['age']);
							$("#gender").html('<b>Gender: </b>'+data.aff_data['gender']);
							$("#foundation_year").html('<b>Foundation Year: </b>'+data.aff_data['foundation_year']);
							$("#whether_registered").html('<b>Whether Registered: </b>'+data.aff_data['whether_registered']);
							$("#subject").html('<b>Subject: </b>'+data.aff_data['subject']);
							$("#no_of_students").html('<b>No of Students: </b>'+data.aff_data['no_of_students']);
							$("#educational_qualifications").html('<b>Educational Qualifications: </b>'+data.aff_data['educational_qualifications']);
							$("#art_qualification").html('<b>Art Qualification: </b>'+data.aff_data['art_qualification']);
							$("#ip").html('<b>IP Location: </b>'+data.aff_data['ip']);
							$("#dtime").html('<b>Date Time: </b>'+data.aff_data['dtime']);

							//files
							if(data.signature_aff_fp != 'undefined'){
								$("#signature_aff_fp").html('<b>Signature: </b> <a href="'+data.signature_aff_fp+'" target="_blank">View/Download</a>');
							}else{
								$("#signature_aff_fp").html('<b>Signature: </b> N/A');
							}
							if(data.photo_aff_fp != 'undefined'){
								$("#photo_aff_fp").html('<b>Photo: </b> <a href="'+data.photo_aff_fp+'" target="_blank">View/Download</a>');
							}else{
								$("#photo_aff_fp").html('<b>Photo: </b> N/A');
							}
							if(data.art_certificate_fp != 'undefined'){
								$("#art_certificate_fp").html('<b>Art Certificate: </b> <a href="'+data.art_certificate_fp+'" target="_blank">View/Download</a>');
							}else{
								$("#art_certificate_fp").html('<b>Art Certificate: </b> N/A');
							}
							if(data.eq_certificate_fp != 'undefined'){
								$("#eq_certificate_fp").html('<b>Eq Certificate: </b> <a href="'+data.eq_certificate_fp+'" target="_blank">View/Download</a>');
							}else{
								$("#eq_certificate_fp").html('<b>Eq Certificate: </b> N/A');
							}
							if(data.address_proof_fp != 'undefined'){
								$("#address_proof_fp").html('<b>Address Proof: </b> <a href="'+data.address_proof_fp+'" target="_blank">View/Download</a>');
							}else{
								$("#address_proof_fp").html('<b>Address Proof: </b> N/A');
							}

							$('#Modal2').modal('toggle');
							$('#Modal2').modal('show');
							//$('#Modal2').modal('hide');

						} else {
							$("#institution_name").html('<b>Error: </b> No Data Found!');
							$('#Modal2').modal('toggle');
							$('#Modal2').modal('show');
						}

					}

				});

			});



		});
	</script>

</body>

</html>